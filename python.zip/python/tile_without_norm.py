from cgi import print_directory
from queue import PriorityQueue
from time import process_time_ns
from turtle import right
import numpy as np
import matplotlib.pyplot as plt
import pickle
import time


def read_pickle(fname):
    with open(fname, 'rb') as f:
        data = pickle.load(f)
        # --
    return data


def normalised(y_data, z_data, n_data):

    """ Normalise the y_data"""
    norm_y = np.linalg.norm(y_data)
    y_norm = y_data / norm_y
    
    """ Normalise the z_data"""
    norm_z = np.linalg.norm(z_data)
    z_norm = z_data / norm_z

    """ Normalise the n_data"""
    norm_n = np.linalg.norm(n_data)
    n_norm = n_data / norm_n

    return y_norm, z_norm, n_norm
range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0
range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0



def get_value_lens(y_lense_norm, z_lense_norm, n_lense_norm,i):
    length = int(np.sqrt(len(y_lense_norm)))
    
    j = i-1
    k = i+1
    
    y_prev = np.array(y_lense_norm[(i-1)*length:(i-1)*length+length])
    z_prev = np.array(z_lense_norm[(i-1)*length:(i-1)*length+length])
    n_prev = np.array(n_lense_norm[(i-1)*length:(i-1)*length+length])
    
    
    y_curr = np.array(y_lense_norm[i*length:i*length+length])
    z_curr = np.array(z_lense_norm[i*length:i*length+length])
    n_curr = np.array(n_lense_norm[i*length:i*length+length])

    y_next = np.array(y_lense_norm[(i+1)*length:(i+1)*length+length])
    z_next = np.array(z_lense_norm[(i+1)*length:(i+1)*length+length])
    n_next = np.array(n_lense_norm[(i+1)*length:(i+1)*length+length])


    '''
    y_prev, z_prev, n_prev  = np.array(b_trim)[:,0], np.array(b_trim)[:,1], np.array(b_trim)[:,2]
    y_curr, z_curr, n_curr  = np.array(a_trim)[:,0], np.array(a_trim)[:,1], np.array(a_trim)[:,2]
    y_next, z_next, n_next  = np.array(c_trim)[:,0], np.array(c_trim)[:,1], np.array(c_trim)[:,2]
    '''

    if(j < 0):
        y_prev, z_prev, n_prev = [0]*length, [0]*length, [0]*length

    if(k >= length):
        y_next, z_next, n_next = [0]*length, [0]*length, [0]*length

    y = [*y_prev, *y_curr, *y_next] 
    z = [*z_prev, *z_curr, *z_next]
    n = [*n_prev, *n_curr, *n_next]
        
    #a_trim_laser = np.array(est[i*length:i*length+length])
    
    #y_curr_laser, z_curr_laser, n_curr_laser = np.array(a_trim_laser)[:,0], np.array(a_trim_laser)[:,1], np.array(a_trim_laser)[:,2]
    return y,z,n


def get_value_laser(y_est_norm, z_est_norm, n_est_norm,i):
    
    j = i-1
    k = i+1

    length = int(np.sqrt(len(y_est_norm)))
    y_curr_laser = np.array(y_est_norm[i*length:i*length+length])
    z_curr_laser = np.array(z_est_norm[i*length:i*length+length])
    n_prev_laser = np.array(n_est_norm[(i-1)*length:(i-1)*length+length])
    n_curr_laser = np.array(n_est_norm[i*length:i*length+length])
    n_next_laser = np.array(n_est_norm[(i+1)*length:(i+1)*length+length])


    if(j < 0):
       n_prev_laser = [0]*length

    if(k >= length):
        n_next_laser = [0]*length

    n_est = [*n_prev_laser, *n_curr_laser, *n_next_laser]
    #y_curr_laser, z_curr_laser, n_curr_laser = np.array(a_trim_laser)[:,0], np.array(a_trim_laser)[:,1], np.array(a_trim_laser)[:,2]

    return y_curr_laser, z_curr_laser,n_curr_laser,n_est


def distance_fun(lens,est):
    global range_1, range_2, range_3, range_4, range_5, range_6, range_7, range_8, range_9
    global range_est_1, range_est_2, range_est_3, range_est_4, range_est_5, range_est_6, range_est_7, range_est_8, range_est_9
    range_1 = range_2 = range_3 = range_4 = range_5  = range_6 = range_7 = range_8 = range_9 = 0
    range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0

    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]
     
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    y_est_norm, z_est_norm, n_est_norm = normalised(y_est, z_est, n_est)

    #print(n_est_norm)
    #print(n_lense_norm)
    length = int(np.sqrt(len(y_est_norm)))
    manhatten_distance = [[0]*(3*length) for i in range(len(est))]
    euclidian_distance = [[0]*(3*length) for i in range(len(est))]
    
    x = 0 
    neighbour1 = [0]*10
    neighbour2 = [0]*10

    for i in range(length):
        y_lens, z_lens, n_lens = get_value_lens(y_lense, z_lense, n_lense, i)
        y_laser,z_laser,n_laser,n_est_1 = get_value_laser(y_est, z_est, n_est, i)

        range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = 0
        range_1 = range_2 = range_3 = range_4 = range_5 = 0

        '''
        print("printing n_lens")
        print(n_lens)
        print("printing n_est")
        print(n_est_1)
        
        '''
        for m in range(len(n_est_1)):    
            if (n_est_1[m] > 0 and n_est_1[m] <= 40) :
                range_est_1 = range_est_1 + 1
        

        for m in range(len(n_est_1)):
            if(n_est_1[m] > 40 and n_est_1[m] <= 80):
                range_est_2 = range_est_2 + 1

        for m in range(len(n_est_1)):
            if(n_est_1[m] > 80 and n_est_1[m] <= 120):
                range_est_3 = range_est_3 + 1

        for m in range(len(n_est_1)):
            if(n_est_1[m] > 120 and n_est_1[m] <= 160):
                range_est_4 = range_est_4 + 1

        for m in range(len(n_est_1)):
            if(n_est_1[m] > 160 and n_est_1[m] <= 180):
                range_est_5 = range_est_5 + 1

        ###################################################################################################

        for m in range(len(n_lens)):    
            if (n_lens[m] > 0 and n_lens[m] <= 40) :
                range_1 = range_1 + 1
        

        for m in range(len(n_lens)):
            if(n_lens[m] > 40 and n_lens[m] <= 80):
                range_2 = range_2 + 1

        for m in range(len(n_lens)):
            if(n_lens[m] > 80 and n_lens[m] <= 120):
                range_3 = range_3 + 1

        for m in range(len(n_lens)):
            if(n_lens[m] > 120 and n_lens[m] <= 160):
                range_4 = range_4 + 1

        for m in range(len(n_lens)):
            if(n_lens[m] > 160 and n_lens[m] <= 180):
                range_5 = range_5 + 1


        print("range1 = %d range 2=%d range3=%d range4=%d range5=%d"%(range_1,range_2,range_3,range_4,range_5))

        print("range_est1 = %d range_est2=%d range_est3=%d range_est4=%d range_est5=%d"%(range_est_1,range_est_2,range_est_3,range_est_4,range_est_5))

        for k  in range(len(y_laser)):
            for j in range(len(y_lens)):
               #manhatten_distance[x][j] = 1*abs(y_laser[k] - y_lens[j]) + 1*abs(z_laser[k] - z_lens[j]) + 0.3*abs(n_laser[k] - n_lens[j]) + 1.0*(abs(range_est_1 - range_1) + abs(range_est_2-range_2) + abs(range_est_3-range_3) + abs(range_est_4 - range_4) + abs(range_est_5 - range_5))
               manhatten_distance[x][j] = 1.0*abs(y_laser[k] - y_lens[j]) + 1.0*abs(z_laser[k] - z_lens[j]) + 1.2*abs(n_laser[k] - n_lens[j])
               euclidian_distance[x][j] = np.sqrt(np.square(y_laser[k]-y_lens[j]) + np.square(z_laser[k] - z_lens[j]) + 1.0*np.square(n_laser[k] - n_lens[j]))
            x = x + 1
            
    return manhatten_distance,euclidian_distance

   
def main():
 
    #fin = "./data/cm_1024_51x51_1.5.pkl"
    #fin = "./data/cm_256_16x16_1.5.pkl"
    #fin = "./data/cm_128_8x8_1.5.pkl"
    #fin = "./data/cm_102_5x5_1.5.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_2.0.pkl"
    #fin = "./data/cm_512_8x8_2.0_8_1.5.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_1.3.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_3.3.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.1.pkl"
    #fin = "./data/cm_256_16x16_3.0_8_1.5.pkl"
    #fin = "./data/cm_256_16x16_2.0_8_1.5.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_2.9.pkl"
    #fin = "./data/cm_102_5x5_2.0_8_2.5.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_5.1.pkl"
    fin = "./data/cm_128_4x4_2.0_8_10.1.pkl"
    #fin = "./data/cm_512_16x16_2.08_1.9.pkl"
    #fin = "./data/cm_1024_32x32_2.0_8_7.0.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.9.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_5.1.pkl"
    


    data = read_pickle(fin)
    lens, est, img_size = data['lens'], data['est'], data['img_size']
    count_euclidian = 0
    count_manhatten = 0
    fig, axs = plt.subplots(2)
    range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = 0
    count = 0 

    #extract lense and laser spot information here 
    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    
    y, z, n = est[:,0], est[:,1], est[:,2]
    
    #print("printing est")
    #print(est)
    length = int(np.sqrt(len(est)))
    
    '''
    for i in range(length):
        a_trim = est[i*length:i*length+length]
        #print(a_trim)
        for i in range(length):
            for k in range(i+1,length):
                if a_trim[i][1] > a_trim[k][1]:
                    a_trim[i][1],a_trim[k][1] = a_trim[k][1],a_trim[i][1]
                    a_trim[i][2],a_trim[k][2] = a_trim[k][2],a_trim[i][2]
                    a_trim[i][0],a_trim[k][0] = a_trim[k][0],a_trim[i][0]
    
    ''' 
    ground_truth = [0]*len(est)
    for i in range(length):
        a_trim = est[i*length:i*length+length]
        #print(a_trim)
        ground_truth[i*length : i*length+length] = i*length + np.argsort((np.argsort(a_trim[:,1])))

    print(ground_truth)
    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]

    euclidian_distance = [[0]*(3*length) for i in range(len(est))]
    manhatten_distance = [[0]*(3*length) for i in range(len(est))]
    manhatten_distance,euclidian_distance = distance_fun(lens,est)


    
    print(manhatten_distance)
    #print(euclidian_distance)

    minInRows_euclidian = np.argmin(euclidian_distance, axis=1)
    minInRows_manhatten = np.argmin(manhatten_distance, axis=1)
    
    #print(minInRows_manhatten)
    #print(minInRows_euclidian)
    output_manhatten = [0]*len(est)
    output_euclidian = [0]*len(est)
    for i in range(len(est)):
        #print(i)
        output_manhatten[i] = minInRows_manhatten[i] - length + (count*length)
        output_euclidian[i] = minInRows_euclidian[i] - length + (count*length)
        if(i%(length) == (length-1)):
            count = count + 1
    #print(output_manhatten)
    #print(output_euclidian)

    
    for k in range(len(minInRows_euclidian)):
       # print("{}       |       {}                           |          {}".format(k, output_euclidian[k],ground_truth[k]))
        if(ground_truth[k] == output_euclidian[k]):
            count_euclidian = count_euclidian + 1
    euclidian_distance = np.array(euclidian_distance)
    
    print("Number of matches_euclidian",(count_euclidian))
    
    
    #print("lense index  | laser spot index")
    for k in range(len(minInRows_manhatten)):
        #print("{}       |       {}                          |         {}".format(k, output_manhatten[k],ground_truth[k]))
        if(ground_truth[k] == output_manhatten[k]):
            count_manhatten = count_manhatten + 1
    manhatten_distance = np.array(manhatten_distance)
    
    print("Number of matches_manhatten",(count_manhatten))
   
if __name__ == "__main__":
    t0= time.time()
    main()
    t1 = time.time() - t0
    print("Time elapsed: ", t1)
   
 
            
            



