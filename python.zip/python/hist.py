import matplotlib.pyplot as plt
data = [1.7,1.8,2.0,2.2,2.2,2.3,2.4,2.5,2.5,2.5,2.6,2.6,2.8,
        2.9,3.0,3.1,3.1,3.2,3.3,3.5,3.6,3.7,4.1,4.1,4.2,4.3]
        
data = [11.1, 23.8, 27.5, 88.7, 165.3, 67.6, 123.3]
#this histogram has a range from 1 to 4
#and 8 different bins
plt.hist(data, range=(0,180), bins=6)
plt.show()