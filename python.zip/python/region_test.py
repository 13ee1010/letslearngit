from cgi import print_directory
from turtle import right
import numpy as np

arr = np.array([1,2,3,4 ,5,6,7,8, 9,10,11,12, 13,14,15,16])
arr_b = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])


index = [0,0,0,0,0,0,0,0,0]
value_lense = [0,0,0,0,0,0,0,0,0]
value_est = [0,0,0,0,0,0,0,0,0]
#arr_2d = np.reshape(arr,(3,3))
manhatten_distance = [[0]*9 for i in range(9)]
euclidian_distance = [[0]*9 for i in range(9)]
bound = len(arr)
bound = int(np.sqrt(bound))
print(bound)
count_euclidian = 0
count_manhatten = 0
count = 0 
def get_value(lens,est,i):
    length = int(np.sqrt(len(est)))
    
    j = i-1
    k = i+1
    #print("printing k",k)
    b_trim = np.array(lens[(i-1)*length:(i-1)*length+length])
    a_trim = np.array(lens[i*length:i*length+length])
    c_trim = np.array(lens[(i+1)*length:(i+1)*length+length])
        
    y_prev = np.array(b_trim)
    y_curr = np.array(a_trim)
    y_next = np.array(c_trim)

    print(y_curr)
    
    if(j < 0):
        y_prev = [0]*length
    if(k >= length):
        y_next = [0]*length
    y = [*y_prev, *y_curr, *y_next] 

      
    a_trim_laser = np.array(est[i*length:i*length+length])
    y_curr_laser = np.array(a_trim_laser)
    return y, y_curr_laser


if __name__ == "__main__":
    
    length = int(np.sqrt(len(arr)))
    manhatten_distance = [[0]*(3*length) for i in range(16)]
    x = 0
    for i in range(length):
        lens_value, laser_value = get_value(arr,arr_b,i)
        #print(lens_value)
        #print(laser_value)
        #print("----------------------------------------")
        
        for k in range(len(laser_value)):
            for j in range(len(lens_value)):
                manhatten_distance[x][j] = abs(laser_value[k] - lens_value[j]) 
            x = x+1
    #print(manhatten_distance)
    
    minInRows_manhatten = np.argmin(manhatten_distance, axis=1)
    output = [0]*len(arr)
    for i in range(16):
        print(i)
        output[i] = minInRows_manhatten[i] - length + (count*length)
        if(i%4 == 3):
            count = count + 1
    print(output)
    #print(minInRows_manhatten)
   

 
            
            



