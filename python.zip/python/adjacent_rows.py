
import numpy as np
x = np.array([[1,2,3], [4,5,6], [7,8,9]])
print(x)

for i in range(len(x)-1):
    print("iterate",i)
    print(x[i-1])
    print(x[i])
    print(x[i+1])
    

