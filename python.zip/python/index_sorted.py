'''
import numpy as np
l = [71, 14, 43, 100]
m = [113,56,86,28]
k = [0]*15
print(k)
k[0:4] = np.argsort(np.argsort(l))
k[4: 4 + 4] = np.argsort(np.argsort(m)) 

print(k)

'''

import numpy as np
l = [71, 14, 43, 100]
print(np.argsort(np.argsort(l)))
print(np.argsort(l))
