import numpy as np 
import matplotlib.pyplot as plt 
  
#X = ['4x4','8x8','16x16','32x32','51x51']
X = ['640x240','1280x720', '1920x1080', '2592x1944']
brute_force = [0.96,8.4,102.1,1605.8,10270]
big_window = [0.9853,2.577,9.0032,34.175,67.102]
small_window = [0.505,1.229,3.395,11.971,25.64]

frame_rate = [56.43, 36.40, 33, 9.96]
camera_fps = [90,60,30,15]
#Throughput = [55,93.16,109.70,132,134.23]

X_axis = np.arange(len(X))
  
plt.bar(X_axis - 0.1, camera_fps, 0.2, label = 'Camera frame fate')
plt.bar(X_axis + 0.1, frame_rate, 0.2, label = 'frame rate of hardware architecture')
#plt.bar(X_axis + 0.3, small_window, 0.2, label = '3xn Window')
  
plt.xticks(X_axis, X)
#plt.yscale("log")
plt.xlabel("Resolution (widthxheight)")
plt.ylabel("Frames per second (fps)")
plt.title("Camera frame rate vs Frame rate of hardware architecture ")
plt.legend()
bottom,top= plt.ylim()

print("Top value:",top)


print("Bottom value:",bottom)
plt.show()