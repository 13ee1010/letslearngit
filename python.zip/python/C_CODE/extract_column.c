#include<stdio.h>
#include<stdlib.h>

int* extract_column(int m[][3], int *b, int column_number)
{
  
  for(int i = 0;i < 3;i++)
  {
    for(int j = 0;j < 3;j++)
    {
      if(j == column_number)
      {
        b[i] = m[i][j];
      }
    }
  }

  return b;
}

float manhatten_distance(int y[][3], int x[])
{

}

int main()
{   
    
    int y[][3] = {{5,6,7}, {8,9,10}, {3,1,2}};
    int x[][3] = {{10,11,13},{13,14,15},{16,17,18}};
    int b[3];
    int c[3];
    int d[3];
    int e[3],f[3],g[3];

    float manhatten_distance[25][25];
    float euclidian_distance[25][25];


    int *y_lense = NULL;    // First column
    int *z_lense = NULL;
    int *n_lense = NULL;

    int *y_est = NULL;
    int *z_est = NULL;
    int *n_est = NULL;

    y_lense = extract_column(x,b,0);
    z_lense = extract_column(x,c,1);
    n_lense = extract_column(x,d,2);

    y_est = extract_column(y,e,0);
    z_est = extract_column(y,f,1);
    n_est = extract_column(y,g,2);
    
   
    printf("%d\n%d\n%d\n", *(y_lense), *(y_lense+1), *(y_lense+2));
    printf("-----------------------------------\n");
    printf("%d\n%d\n%d\n", *(z_lense), *(z_lense+1), *(z_lense+2));
    printf("------------------------------------\n");
    printf("%d\n%d\n%d\n", *(n_lense), *(n_lense+1), *(n_lense+2));
    printf("-------------------------------------\n");
     
    printf("%d\n%d\n%d\n", *(y_est), *(y_est+1), *(y_est+2));
    printf("-----------------------------------\n");
    printf("%d\n%d\n%d\n", *(z_est), *(z_est+1), *(z_est+2));
    printf("------------------------------------\n");
    printf("%d\n%d\n%d\n", *(n_est), *(n_est+1), *(n_est+2));
    printf("-------------------------------------\n");

   





    return 0;
}