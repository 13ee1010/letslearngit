from cgi import print_directory
from queue import PriorityQueue
from time import process_time_ns
from turtle import right
import numpy as np
import matplotlib.pyplot as plt
import pickle
import time

def read_pickle(fname):
    with open(fname, 'rb') as f:
        data = pickle.load(f)
        # --
    return data

def normalised(y_data, z_data, n_data):

    """ Normalise the y_data"""
    norm_y = np.linalg.norm(y_data)
    y_norm = y_data / norm_y
    
    """ Normalise the z_data"""
    norm_z = np.linalg.norm(z_data)
    z_norm = z_data / norm_z

    """ Normalise the n_data"""
    norm_n = np.linalg.norm(n_data)
    n_norm = n_data / norm_n

    return y_norm, z_norm, n_norm
range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0
range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0



def distance_fun(lens,est):
    global range_1, range_2, range_3, range_4, range_5, range_6, range_7, range_8, range_9
    global range_est_1, range_est_2, range_est_3, range_est_4, range_est_5, range_est_6, range_est_7, range_est_8, range_est_9
    range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0
    range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0

    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]
     
    '''
    for i in range(len(n_est)):
        if( n_est[i] > 175.0):
            n_est[i] = np.sin(np.deg2rad(n_est[i]))
    '''
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    y_est_norm, z_est_norm, n_est_norm = normalised(y_est, z_est, n_est)

   
    bound = len(y_lense)
    bound = int(np.sqrt(bound))
    
    check = 0.0
    check2= 0.0
    centreX = 0
    centreY = 0
    centreX1 = 0
    centreY1 = 0

    neighbour1 = [0]*10
    neighbour2 = [0]*10
    index = [0]*9
    angle_diff = 0 
    count1 = 0
    count2 = 0
    count3 = 0

    manhatten_distance = [[0]*len(lens) for i in range(len(est))]
    euclidian_distance = [[0]*len(lens) for i in range(len(est))]
    
    for k in range (len(est)):
        
        count1 = 0
        #centreX = z_est[k]
        #centreY = y_est[k] 


        neighbour1 =[0 for i in range(len(neighbour1))] 
        neighbour2 = [0 for i in range(len(neighbour1))] 
        
        '''
        for i in range (len(est)):
            for j in range(len(est)):
                if(i==j):
                    check = ((z_est[i]) - (centreX))*((z_est[i])-(centreX)) + ((y_est[j])-(centreY))*((y_est[j])-(centreY))
                    if(check <= 1000):
                        neighbour1[count1] = n_est_norm[i]
                        count1 = count1 + 1
      
        range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7= range_est_8 = range_est_9 = 0
        
        
        for m in range(len(neighbour1)):    
            if (neighbour1[m] > 0 and neighbour1[m] <= 0.2) :
                range_est_1 = range_est_1 + 1
        

        for m in range(len(neighbour1)):
            if(neighbour1[m] > 0.2 and neighbour1[m] <= 0.4):
                range_est_2 = range_est_2 + 1

        for m in range(len(neighbour1)):
            if(neighbour1[m] > 0.4 and neighbour1[m] <= 0.6):
                range_est_3 = range_est_3 + 1

        for m in range(len(neighbour1)):
            if(neighbour1[m] > 0.6 and neighbour1[m] <= 0.8):
                range_est_4 = range_est_4 + 1

        for m in range(len(neighbour1)):
            if(neighbour1[m] > 0.8 and neighbour1[m] <= 1.0):
                range_est_5 = range_est_5 + 1
        '''
           
        
        for x in range(len(lens)):
            count2 = 0

            #centreX1 = z_lense[x]
            #centreY1 = y_lense[x]

            neighbour2 = [0 for i in range(len(neighbour2))] 
            range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0
            
            '''
            for l in range(len(est)):
                for m in range(len(est)):
                    if(l==m):
                        check2 = (((z_lense[l] - centreX1)*(z_lense[l] - centreX1))  + ((y_lense[m] - centreY1)*(y_lense[m] - centreY1))) 
                        if(check2 <= 4.1):
                            neighbour2[count2] = n_lense_norm[l] 
                            count2 = count2 + 1 
            

            for m in range(len(neighbour2)):
                if(neighbour2[m] > 0 and neighbour2[m] <= 0.2):
                    range_1 = range_1 + 1

            for m in range(len(neighbour2)):
                if(neighbour2[m] > 0.2 and neighbour2[m] <= 0.4):
                    range_2 = range_2 + 1

            for m in range(len(neighbour2)):
                if(neighbour2[m] > 0.4 and neighbour2[m] <= 0.6):
                    range_3 = range_3 + 1

            for m in range(len(neighbour2)):
                if(neighbour2[m] > 0.6 and neighbour2[m] <= 0.8):
                    range_4 = range_4 + 1

            for m in range(len(neighbour2)):
                if(neighbour2[m] > 0.8 and neighbour2[m] <= 1.0):
                    range_5 = range_5 + 1
            '''
            #angle_diff = np.sin(np.deg2rad(n_est[k])) - np.sin(np.deg2rad(n_lense[x]))
            #manhatten_distance[k][x] = 1*abs(z_est_norm[k] - z_lense_norm[x]) + 1*abs(y_est_norm[k] - y_lense_norm[x]) + 1*abs(n_est_norm[k] - n_lense_norm[x])  + 0.0*(abs(range_est_1 - range_1) + abs(range_est_2-range_2) + abs(range_est_3-range_3) + abs(range_est_4 - range_4) + abs(range_est_5 - range_5))
            manhatten_distance[k][x] = 1*abs(z_est_norm[k] - z_lense_norm[x]) + 1*abs(y_est_norm[k] - y_lense_norm[x]) + 1*abs(n_est_norm[k] - n_lense_norm[x]) 

            euclidian_distance[k][x] = np.sqrt(np.square(z_est_norm[k]- z_lense_norm[x]) + np.square(y_est_norm[k] - y_lense_norm[x]) + 0.3*(np.square(1*abs(n_est_norm[k] - n_lense_norm[x]) )))
    return manhatten_distance,euclidian_distance

def main():
 
    #fin = "./data/cm_1024_51x51_1.5.pkl"
    #fin = "./data/cm_256_16x16_1.5.pkl"
    #fin = "./data/cm_128_8x8_1.5.pkl"
    #fin = "./data/cm_102_5x5_1.5.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_2.0.pkl"
    #fin = "./data/cm_512_8x8_2.0_8_1.5.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_10.1.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_3.3.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.1.pkl"
    #fin = "./data/cm_256_16x16_3.0_8_1.5.pkl"
    #fin = "./data/cm_256_16x16_2.0_8_1.5.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.7.pkl"
    #fin = "./data/cm_102_5x5_2.0_8_2.5.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_5.1.pkl"
    fin = "./data/cm_128_4x4_2.0_8_0.7.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.9.pkl"
    #fin = "./data/cm_1024_32x32_2.0_8_1.1.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.9.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_5.1.pkl"
    


    data = read_pickle(fin)
    lens, est, img_size = data['lens'], data['est'], data['img_size']
    count_euclidian = 0
    count_manhatten = 0
    fig, axs = plt.subplots(2)
    range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = 0


    #extract lense and laser spot information here 
    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    print(lens)
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    
    y, z, n = est[:,0], est[:,1], est[:,2]
    print(est)
    
    length = int(np.ceil(np.sqrt(len(est))))
    ground_truth = [0]*len(est)
    for i in range(length):
        a_trim = est[i*length:i*length+length]
        #print(a_trim)
        ground_truth[i*length : i*length+length] = i*length + np.argsort((np.argsort(a_trim[:,1])))

    print(ground_truth)



    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]
    euclidian_distance = [[0]*(len(lens)) for i in range(len(est))]
    manhatten_distance = [[0]*(len(lens)) for i in range(len(est))]
    manhatten_distance,euclidian_distance = distance_fun(lens,est)


    
    print(manhatten_distance)
    #print(euclidian_distance)

    minInRows_euclidian = np.argmin(euclidian_distance, axis=1)
    minInRows_manhatten = np.argmin(manhatten_distance, axis=1)
    
    print(minInRows_manhatten)
    print(minInRows_euclidian)

  
    for k in range(len(minInRows_euclidian)):
        #print("{}       |       {}                           |          {}".format(k, minInRows_euclidian[k],ground_truth[k]))
        if(ground_truth[k] == minInRows_euclidian[k]):
            count_euclidian = count_euclidian + 1
    euclidian_distance = np.array(euclidian_distance)
    print("Number of matches_euclidian",(count_euclidian))
    
    #print("lense index  | laser spot index")
    for k in range(len(minInRows_manhatten)):
        #print("{}       |       {}                          |         {}".format(k, minInRows_manhatten[k],ground_truth[k]))
        if(ground_truth[k] == minInRows_manhatten[k]):
            count_manhatten = count_manhatten + 1
    manhatten_distance = np.array(manhatten_distance)
    print("Number of matches_manhatten",(count_manhatten))

   
if __name__ == "__main__":
    t0= time.time()
    main()
    t1 = time.time() - t0
    print("Time elapsed: ", t1)
   