from cgi import print_directory
from queue import PriorityQueue
from time import process_time_ns
from traceback import print_tb
from turtle import right
import numpy as np
import matplotlib.pyplot as plt
import pickle
import time


def read_pickle(fname):
    with open(fname, 'rb') as f:
        data = pickle.load(f)
        # --
    return data


def normalised(y_data, z_data, n_data):

    """ Normalise the y_data"""
    norm_y = np.linalg.norm(y_data)
    y_norm = y_data / norm_y
    
    """ Normalise the z_data"""
    norm_z = np.linalg.norm(z_data)
    z_norm = z_data / norm_z

    """ Normalise the n_data"""
    norm_n = np.linalg.norm(n_data)
    n_norm = n_data / norm_n

    return y_norm, z_norm, n_norm


def normalised_single(data):
    """ Normalise the n_data"""
    norm_data = np.linalg.norm(data)
    norm_d = data / norm_data

    return norm_d

range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0
range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0

def min_n_nums(nums, n = 1):
  return sorted(nums, reverse = False)[:n]



def get_value_lens(y_lense_norm, z_lense_norm, n_lense_norm,n_lense, i):
    length = int(np.sqrt(len(y_lense_norm)))
    
    j = i-1
    k = i+1
    
    y_prev = np.array(y_lense_norm[(i-1)*length:(i-1)*length+length])
    z_prev = np.array(z_lense_norm[(i-1)*length:(i-1)*length+length])
    n_prev = np.array(n_lense_norm[(i-1)*length:(i-1)*length+length])
    
    
    y_curr = np.array(y_lense_norm[i*length:i*length+length])
    z_curr = np.array(z_lense_norm[i*length:i*length+length])
    n_curr = np.array(n_lense_norm[i*length:i*length+length])

    y_next = np.array(y_lense_norm[(i+1)*length:(i+1)*length+length])
    z_next = np.array(z_lense_norm[(i+1)*length:(i+1)*length+length])
    n_next = np.array(n_lense_norm[(i+1)*length:(i+1)*length+length])
    
    
    n_prev_angle = np.array(n_lense[(i-1)*length:(i-1)*length+length])
    n_curr_angle = np.array(n_lense[i*length:i*length+length])
    n_next_angle = np.array(n_lense[(i+1)*length:(i+1)*length+length])
    
    '''
    y_prev, z_prev, n_prev  = np.array(b_trim)[:,0], np.array(b_trim)[:,1], np.array(b_trim)[:,2]
    y_curr, z_curr, n_curr  = np.array(a_trim)[:,0], np.array(a_trim)[:,1], np.array(a_trim)[:,2]
    y_next, z_next, n_next  = np.array(c_trim)[:,0], np.array(c_trim)[:,1], np.array(c_trim)[:,2]
    '''

    if(j < 0):
        y_prev, z_prev, n_prev, n_prev_angle = [0]*length, [0]*length, [0]*length, [0]*length

    if(k >= length):
        y_next, z_next, n_next, n_next_angle = [0]*length, [0]*length, [0]*length, [0]*length

    y = [*y_prev, *y_curr, *y_next] 
    z = [*z_prev, *z_curr, *z_next]
    n = [*n_prev, *n_curr, *n_next]

    n_lense_angle = [*n_prev_angle, *n_curr_angle, *n_next_angle]    
    #a_trim_laser = np.array(est[i*length:i*length+length])
    
    #y_curr_laser, z_curr_laser, n_curr_laser = np.array(a_trim_laser)[:,0], np.array(a_trim_laser)[:,1], np.array(a_trim_laser)[:,2]
    return y,z,n,n_lense_angle


def get_value_laser(y_est_norm, z_est_norm, n_est_norm, i):
    
    j = i-1
    k = i+1
   
    length = int(np.sqrt(len(y_est_norm)))


    y_prev_laser = np.array(y_est_norm[(i-1)*length:(i-1)*length+length])
    z_prev_laser = np.array(z_est_norm[(i-1)*length:(i-1)*length+length])
    n_prev_laser = np.array(n_est_norm[(i-1)*length:(i-1)*length+length])
    
    y_curr_laser = np.array(y_est_norm[i*length:i*length+length])
    z_curr_laser = np.array(z_est_norm[i*length:i*length+length])
    n_curr_laser = np.array(n_est_norm[i*length:i*length+length])

    y_next_laser = np.array(y_est_norm[(i+1)*length:(i+1)*length+length])
    z_next_laser = np.array(z_est_norm[(i+1)*length:(i+1)*length+length])
    n_next_laser = np.array(n_est_norm[(i+1)*length:(i+1)*length+length])


    if(j < 0):
        y_prev_laser, z_prev_laser, n_prev_laser, n_prev = [0]*length, [0]*length, [0]*length, [0]*length


    if(k >= length):
        y_next_laser, z_next_laser, n_next_laser, n_next = [0]*length, [0]*length, [0]*length, [0]*length

    
    y_laser = [*y_prev_laser, *y_curr_laser, *y_next_laser] 
    z_laser = [*z_prev_laser, *z_curr_laser, *z_next_laser]
    n_laser = [*n_prev_laser, *n_curr_laser, *n_next_laser]

    
    #print(n_est_angle)
    #y_curr_laser, z_curr_laser, n_curr_laser = np.array(a_trim_laser)[:,0], np.array(a_trim_laser)[:,1], np.array(a_trim_laser)[:,2]

    return y_laser, z_laser, n_laser, y_curr_laser, z_curr_laser, n_curr_laser


def distance_fun(lens,est):
    global range_1, range_2, range_3, range_4, range_5, range_6, range_7, range_8, range_9
    global range_est_1, range_est_2, range_est_3, range_est_4, range_est_5, range_est_6, range_est_7, range_est_8, range_est_9
    range_1 = range_2 = range_3 = range_4 = range_5  = range_6 = range_7 = range_8 = range_9 = 0
    range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7 = range_est_8 = range_est_9 = 0

    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]
     
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    y_est_norm, z_est_norm, n_est_norm = normalised(y_est, z_est, n_est)

    #print(z_est_norm)
    #print(n_lense_norm)
    #length = int(np.ceil((np.sqrt(len(y_est_norm))))
    length = int(np.ceil(np.sqrt(len(y_est_norm))))
    manhatten_distance = [[0]*(3*length) for i in range(len(est))]
    euclidian_distance = [[0]*(3*length) for i in range(len(est))]
    
    x = 0 
    neighbour1 = [0]*7
    neighbour2 = [0]*7
    range_lense = [0]*6
    range_est = [0]*6 
    minimum_distance = [0]*3*length
    angle_info = [0]*3*length
    angle_info_2 = [0]*4*length
    distance2 = [0]*3*length
    five_minimum = [0]*10
    count1 = 0
    for i in range(length): #length
        y_lens, z_lens, n_lens, n_lense_angle = get_value_lens(y_lense_norm, z_lense_norm, n_lense_norm, n_lense, i)
        y_laser,z_laser,n_laser, y_curr_laser, z_curr_laser, n_curr_laser = get_value_laser(y_est_norm, z_est_norm, n_est_norm, i)
        count1 = 0
        
       
        
        neighbour1 =[0 for i in range(len(neighbour1))] 
        neighbour2 = [0 for i in range(len(neighbour2))] 
        for k in range(len(y_curr_laser)): #y_curr_laser
            #t2 = time.time()
            for l in range(len(y_laser)):
                minimum_distance[l]= abs(y_curr_laser[k] - y_laser[l]) + abs(z_curr_laser[k] - z_laser[l])
                #minimum_distance[l]=  abs(z_curr_laser[k] - z_laser[l])
                angle_info[l] = n_laser[l]
                check1 = abs(y_curr_laser[k] - y_laser[l]) + abs(z_curr_laser[k] - z_laser[l])
            res = sorted(range(len(minimum_distance)), key = lambda sub: minimum_distance[sub])[:7]
           
            for s in range(len(res)):
                neighbour1[s] = angle_info[res[s]]


            
            range_est_1 = range_est_2 = range_est_3 = range_est_4 = range_est_5 = range_est_6 = range_est_7= range_est_8 = range_est_9 = 0

            for m in range(len(neighbour1)):    
                if (neighbour1[m] > 0 and neighbour1[m] <= 0.2) :
                    range_est_1 = range_est_1 + 1
        

            for m in range(len(neighbour1)):
                if(neighbour1[m] > 0.2 and neighbour1[m] <= 0.4):
                    range_est_2 = range_est_2 + 1

            for m in range(len(neighbour1)):
                if(neighbour1[m] > 0.4 and neighbour1[m] <= 0.6):
                    range_est_3 = range_est_3 + 1

            for m in range(len(neighbour1)):
                if(neighbour1[m] > 0.6 and neighbour1[m] <= 0.8):
                    range_est_4 = range_est_4 + 1

            for m in range(len(neighbour1)):
                if(neighbour1[m] > 0.8 and neighbour1[m] <= 1.0):
                    range_est_5 = range_est_5 + 1
            
            

            for j in range(len(y_lens)):
                
                neighbour2 = [0 for i in range(len(neighbour2))] 
                range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = range_7 = range_8 = range_9 = 0

                for m in range(len(y_lens)):
                    distance2[m] = abs(y_lens[j] - y_lens[m]) + abs(z_lens[j] - z_lens[m])

                    #distance2[m] = abs(z_lens[j] - z_lens[m])
                    angle_info_2[m] = n_lens[m]
                res2 = sorted(range(len(distance2)), key = lambda sub: distance2[sub])[:7]


                for s in range(len(res2)):
                    neighbour2[s] = angle_info_2[res2[s]]

                

                for m in range(len(neighbour2)):
                    if(neighbour2[m] > 0 and neighbour2[m] <= 0.2):
                        range_1 = range_1 + 1

                for m in range(len(neighbour2)):
                    if(neighbour2[m] > 0.2 and neighbour2[m] <= 0.4):
                        range_2 = range_2 + 1

                for m in range(len(neighbour2)):
                    if(neighbour2[m] > 0.4 and neighbour2[m] <= 0.6):
                        range_3 = range_3 + 1

                for m in range(len(neighbour2)):
                    if(neighbour2[m] > 0.6 and neighbour2[m] <= 0.8):
                        range_4 = range_4 + 1

                for m in range(len(neighbour2)):
                    if(neighbour2[m] > 0.8 and neighbour2[m] <= 1.0):
                        range_5 = range_5 + 1
               



                angle_diff = np.sin(np.deg2rad(n_est[k])) - np.sin(np.deg2rad(n_lense[x]))
                manhatten_distance[x][j] = (abs(y_curr_laser[k] - y_lens[j])) + (abs(z_curr_laser[k] - z_lens[j])) + (abs(n_curr_laser[k] - n_lens[j])) + 0*(abs(range_est_1 - range_1) + abs(range_est_2 - range_2) + abs(range_est_3 - range_3) + abs(range_est_4 - range_4) + abs(range_est_5 - range_5) + abs(range_est_6 - range_6))
               
                euclidian_distance[x][j] = np.sqrt(np.square(y_curr_laser[k]-y_lens[j]) + np.square(z_curr_laser[k] - z_lens[j])+ np.square(n_curr_laser[k] - n_lens[j]))  +  0*np.square((np.square(range_est_1 - range_1)  +  np.square(range_est_2 - range_2) + np.square(range_est_3 - range_3) + np.square(range_est_4 - range_4) + np.square(range_est_5 - range_5)))
            #t3 = time.time() - t2
            #print("Time elapsed: ", t3)
            x = x + 1
                
    
    
    return manhatten_distance,euclidian_distance

   
def main():
 
    #fin = "./data/cm_1024_51x51_1.5.pkl"
    #fin = "./data/cm_256_16x16_1.5.pkl"
    #fin = "./data/cm_128_8x8_1.5.pkl"
    #fin = "./data/cm_102_5x5_1.5.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_1.3.pkl"
    #fin = "./data/cm_512_8x8_2.0_8_1.5.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_1.7.pkl"
    #fin = "./data/cm_256_8x8_2.0_8_3.3.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_10.1.pkl"
    #fin = "./data/cm_256_16x16_3.0_8_1.5.pkl"
    #fin = "./data/cm_256_16x16_2.0_8_1.5.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.7.pkl"
    #fin = "./data/cm_102_5x5_2.0_8_2.5.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_5.1.pkl"
    fin = "./data/cm_128_4x4_2.0_8_1.0.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.9.pkl"
    #fin = "./data/cm_1024_32x32_2.0_8_2.5.pkl"
    #fin = "./data/cm_512_16x16_2.0_8_1.9.pkl"
    #fin ="./data/cm_1024_51x51_2.0_8_2.5.pkl"
    #fin ="./data/cm_2048_51x51_2.0_8_1.1.pkl"
    


    data = read_pickle(fin)
    lens, est, img_size = data['lens'], data['est'], data['img_size']
    #print(lens)
    count_euclidian = 0
    count_manhatten = 0
    fig, axs = plt.subplots(2)
    range_1 = range_2 = range_3 = range_4 = range_5 = range_6 = 0
    count = 0 

    #extract lense and laser spot information here 
    y_lense, z_lense, n_lense = lens[:,0], lens[:,1], lens[:,2]
    y_lense_norm, z_lense_norm, n_lense_norm = normalised(y_lense,z_lense,n_lense)
    
    y, z, n = est[:,0], est[:,1], est[:,2]
    #print(est)
    #print("printing est")
    #print(est)
    length = int(np.ceil(np.sqrt(len(est))))
    print(length)
    '''
    for i in range(length):
        a_trim = est[i*length:i*length+length]
        #print(a_trim)
        for i in range(length):
            for k in range(i+1,length):
                if a_trim[i][1] > a_trim[k][1]:
                    a_trim[i][1],a_trim[k][1] = a_trim[k][1],a_trim[i][1]
                    a_trim[i][2],a_trim[k][2] = a_trim[k][2],a_trim[i][2]
                    a_trim[i][0],a_trim[k][0] = a_trim[k][0],a_trim[i][0]
    
    ''' 
    ground_truth = [0]*len(est)
    for i in range(length):
        a_trim = est[i*length:i*length+length]
        
        ground_truth[i*length : i*length+length] = i*length + np.argsort((np.argsort(a_trim[:,1])))

    print(ground_truth)
    y_est, z_est, n_est = est[:,0], est[:,1], est[:,2]

    euclidian_distance = [[0]*(3*length) for i in range(len(est))]
    manhatten_distance = [[0]*(3*length) for i in range(len(est))]
    manhatten_distance,euclidian_distance = distance_fun(lens,est)


    
    #print(manhatten_distance)
    #print(euclidian_distance)

    minInRows_euclidian = np.argmin(euclidian_distance, axis=1)
    minInRows_manhatten = np.argmin(manhatten_distance, axis=1)
    
    print(minInRows_manhatten)
    print(minInRows_euclidian)
    output_manhatten = [0]*len(est)
    output_euclidian = [0]*len(est)
    for i in range(len(est)):
        #print(i)
        output_manhatten[i] = minInRows_manhatten[i] - length + (count*length)
        output_euclidian[i] = minInRows_euclidian[i] - length + (count*length)
        if(i%(length) == (length-1)):
            count = count + 1
    print(output_manhatten)
    print(output_euclidian)

    
    for k in range(len(minInRows_euclidian)):
        #print("{}       |       {}                           |          {}".format(k, output_euclidian[k],ground_truth[k]))
        if(ground_truth[k] == output_euclidian[k]):
            count_euclidian = count_euclidian + 1
    euclidian_distance = np.array(euclidian_distance)
    print("Number of matches_euclidian",(count_euclidian))
    
    #print("lense index  | laser spot index")
    for k in range(len(minInRows_manhatten)):
       #print("{}       |       {}                          |         {}".format(k, output_manhatten[k],ground_truth[k]))
        if(ground_truth[k] == output_manhatten[k]):
            count_manhatten = count_manhatten + 1
    manhatten_distance = np.array(manhatten_distance)
    print("Number of matches_manhatten",(count_manhatten))
    
   
if __name__ == "__main__":
    t0= time.time()
    main()
    t1 = time.time() - t0
    print("Time elapsed: ", t1)
   
 
            
            



